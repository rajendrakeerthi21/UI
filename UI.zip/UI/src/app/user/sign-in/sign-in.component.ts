import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Shared/user.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  constructor(private userService : UserService,private router : Router) { }

  ngOnInit() {
  }
  
  isLoginError : boolean = false;

  OnSubmit(userName,password){
    alert('Test');
    debugger;
    this.userService.userAuthentication(userName,password).subscribe((data : any)=>{
      debugger;
     localStorage.setItem('userToken',data.access_token);
     this.router.navigate(['/home']);
   },
   (err : HttpErrorResponse)=>{
     this.isLoginError = true;
   });
 }

}
