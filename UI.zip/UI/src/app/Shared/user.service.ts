import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs';
import { User } from './user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  readonly rootUrl = 'http://localhost:51346';
  constructor(private http: HttpClient) { }

  registerUser(user : User){
    debugger;
    const body: User = {
      UserName: user.UserName,
      Password: user.Password,
      Email: user.Email,
      FirstName: user.FirstName,
      LastName: user.LastName
    }

    let PostContractTypedata = JSON.stringify(body);
    let body1 = JSON.parse(PostContractTypedata);

    let private_options = { headers: new HttpHeaders(
      { 
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Credentials': 'true'
      }) };
    return this.http.post(this.rootUrl + '/api/User/Register', body1, private_options);
  }


  userAuthentication(userName, password) {
    var data = "username=" + userName + "&password=" + password + "&grant_type=password";
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-urlencoded' });
    return this.http.post(this.rootUrl + '/token', data, { headers: reqHeader });
  }
}
